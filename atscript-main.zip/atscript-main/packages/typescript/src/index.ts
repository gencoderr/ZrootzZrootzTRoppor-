import { tsPlugin } from './plugin'

export default tsPlugin

export * from './annotated-type'
export * from './validator'
export * from './json-schema'
