import { SemanticGroup } from './group-node'

export class SemanticTupleNode extends SemanticGroup {
  constructor() {
    super()
    this.entity = 'tuple'
  }
}
