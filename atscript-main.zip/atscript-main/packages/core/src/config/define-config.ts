import type { TAtscriptConfig } from './types'

/**
 * Defines the configuration for the Intertation parser
 */
export function defineConfig(config: TAtscriptConfig): TAtscriptConfig {
  return config
}
