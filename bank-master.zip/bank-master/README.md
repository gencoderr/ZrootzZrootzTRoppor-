# Bank

See the [introductory blog post][] and the [wiki][] for more information.

[introductory blog post]: http://gofreerange.com/project-credit-union-day-1
[wiki]: https://github.com/freerange/bank/wiki
