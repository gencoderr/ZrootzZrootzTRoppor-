
# 🍿 A crowdsourced list of hacker movies, tv shows and podcasts

🙋 Have one to add? Submit a pull request

| Title      | Link |
| ----------- | ----------- |
| The Animatrix      | <https://en.wikipedia.org/wiki/The_Animatrix>     |
| Antitrust   | <https://en.wikipedia.org/wiki/Antitrust_(film)>        |
| Beverly Hills Cop | <https://en.wikipedia.org/wiki/Beverly_Hills_Cop> |
| BlackBerry | <https://www.blackberrymovie.com/> |
| Blackhat | <https://en.wikipedia.org/wiki/Blackhat_(film)> |
| Blade Runner | <https://en.wikipedia.org/wiki/Blade_Runner> |
| CSI: Cyber | <https://en.wikipedia.org/wiki/CSI:_Cyber> |
| Darknet Diaries Podcast | <https://en.wikipedia.org/wiki/Darknet_Diaries> | 
| Die Hard 4.0      | <https://en.wikipedia.org/wiki/Live_Free_or_Die_Hard>       |
| Enemy of the State | <https://en.wikipedia.org/wiki/Enemy_of_the_State_(film)> |
| Fletch | <https://en.wikipedia.org/wiki/Fletch_(film)> |
| Ghost in the Shell   | <https://en.wikipedia.org/wiki/Ghost_in_the_Shell>        |
| Hackers      | <https://en.wikipedia.org/wiki/Hackers_(film)>      |
| Hacker (2016) | <https://en.wikipedia.org/wiki/Hacker_(film)> |
| Halt and Catch Fire   | <https://en.wikipedia.org/wiki/Halt_and_Catch_Fire_(TV_series)>        |
| i, ROBOT | <https://en.wikipedia.org/wiki/I,_Robot_(film)> |
| Johnny Mnemonic      | <https://en.wikipedia.org/wiki/Johnny_Mnemonic>       |
| The KGB, the Computer and Me | <https://archive.org/details/The_KGB_The_Computer_and_Me_1990> |
| The Matrix   | <https://en.wikipedia.org/wiki/The_Matrix>        |
| Max Headroom hack      | <https://news.wttw.com/2017/11/21/30-years-later-notorious-max-headroom-incident-remains-mystery>       |
| Mr Robot   | <https://en.wikipedia.org/wiki/Mr._Robot>        |
| NCIS hacking scene | <https://youtu.be/kl6rsi7BEtk?si=OYBhy3ie8VJeWJck> |
| Pantheon | <https://www.imdb.com/title/tt11680642/?ref_=nm_flmg_t_1_act> |
| Serial Experiments Lain | <https://en.wikipedia.org/wiki/Serial_Experiments_Lain>       |
| Silicon Valley   | <https://en.wikipedia.org/wiki/Silicon_Valley_(TV_series)>        |
| Sneakers      | <https://en.wikipedia.org/wiki/Sneakers_(1992_film)>       |
| Swordfish   | <https://en.wikipedia.org/wiki/Swordfish_(film)>        |
| Terminator 2: Judgment Day | <https://en.wikipedia.org/wiki/Terminator_2:_Judgment_Day> |
| The Net       | <https://en.wikipedia.org/wiki/The_Net_(1995_film)>       |
| The Thirteenth Floor   | <https://en.wikipedia.org/wiki/The_Thirteenth_Floor>        |
| Tron      | <https://en.wikipedia.org/wiki/Tron>       |
| WarGames   | <https://en.wikipedia.org/wiki/WarGames>        |
| Who Am I | <https://www.imdb.com/title/tt3042408/> |
