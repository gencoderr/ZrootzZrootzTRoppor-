from peewee import Proxy

database_proxy = Proxy()
