#!/bin/bash

docker exec -i 8cb5b793a81c mysql -uroot -pp@ssw0rd troll_bot < troll_bot_db.sql