"""
    COPYRIGHT DISCLAIMER

    Script : PhoneSploit Pro - All in One Android Hacking ADB Toolkit  

    Copyright (C) 2023  Mohd Azeem (github.com/AzeemIdrisi)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

    Forking and modifying are allowed, but credit must be given to the
    original developer, [Mohd Azeem (github.com/AzeemIdrisi)], and copying the code
    is not permitted without permission.

    For any queries, Contact me at : azeemidrisi@protonmail.com
"""

RED = "\033[91m"
GREEN = "\033[92m"
# ORANGE = '\033[33m'
YELLOW = "\033[93m"
# BLUE = '\033[94m'
PURPLE = "\033[95m"
CYAN = "\033[96m"
WHITE = "\033[97m"


color_list = [RED, GREEN, YELLOW, PURPLE, CYAN, WHITE]

"""
Copyright © 2023 Mohd Azeem (github.com/AzeemIdrisi)
"""
